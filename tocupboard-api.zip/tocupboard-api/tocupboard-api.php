<?php
/*
Plugin Name: ToCupboard API Integrations
Description: Llamadas a API externa (catálogo) y formulario de contacto seguro (POST) + ajustes.
Version: 1.2.0
Author: ToCupboard Team
*/

if (!defined('ABSPATH')) { exit; }

final class ToCupboard_API_Integrations {
  const OPT_BASE_URL = 'tocup_api_base_url';
  const OPT_API_KEY  = 'tocup_api_key';

  public function __construct() {
    // Ajustes en admin
    add_action('admin_menu',  [$this,'add_settings_page']);
    add_action('admin_init',  [$this,'register_settings']);

    // Shortcodes
    add_shortcode('tocup_products', [$this,'shortcode_products']);
    add_shortcode('tocup_contact',  [$this,'shortcode_contact']);

    // Estilos mínimos
    add_action('wp_enqueue_scripts', [$this,'enqueue_styles']);
  }

  /* ---------- Ajustes ---------- */
  public function add_settings_page() {
    add_options_page('ToCupboard API', 'ToCupboard API', 'manage_options', 'tocup-api', [$this,'render_settings']);
  }

  public function register_settings() {
    register_setting('tocup_api_group', self::OPT_BASE_URL, [
      'type' => 'string',
      'sanitize_callback' => 'esc_url_raw',
      'default' => 'https://dummyjson.com',
    ]);
    register_setting('tocup_api_group', self::OPT_API_KEY, [
      'type' => 'string',
      'sanitize_callback' => 'sanitize_text_field',
      'default' => '',
    ]);
  }

  public function render_settings() { ?>
    <div class="wrap">
      <h1>ToCupboard API – Ajustes</h1>
      <form method="post" action="options.php">
        <?php settings_fields('tocup_api_group'); do_settings_sections('tocup_api_group'); ?>
        <table class="form-table" role="presentation">
          <tr>
            <th scope="row"><label for="tocup_api_base_url">Base URL</label></th>
            <td>
              <input type="url" id="tocup_api_base_url" name="<?php echo esc_attr(self::OPT_BASE_URL); ?>"
                value="<?php echo esc_attr(get_option(self::OPT_BASE_URL,'https://dummyjson.com')); ?>"
                class="regular-text" />
              <p class="description">Ej: https://dummyjson.com</p>
            </td>
          </tr>
          <tr>
            <th scope="row"><label for="tocup_api_key">API Key (opcional)</label></th>
            <td>
              <input type="text" id="tocup_api_key" name="<?php echo esc_attr(self::OPT_API_KEY); ?>"
                value="<?php echo esc_attr(get_option(self::OPT_API_KEY,'')); ?>" class="regular-text" />
              <p class="description">Se enviará como Authorization: Bearer &lt;key&gt;</p>
            </td>
          </tr>
        </table>
        <?php submit_button(); ?>
      </form>
    </div>
  <?php }

  /* ---------- Shortcode: catálogo (GET) ---------- */
public function shortcode_products($atts) {
     if (function_exists('is_shop') && is_shop()) { return ''; }
  $atts = shortcode_atts([
    'limit'    => 8,                    // número de ítems
    'endpoint' => 'products',           // ruta libre, p.ej. products/category/groceries
    'category' => '',                   // atajo: si lo pones, ignora endpoint
    'nocache'  => '0',                  // pon "1" para refrescar
    'debug'    => '0',                  // pon "1" para imprimir la URL
  ], $atts, 'tocup_products');

  $limit = max(1, intval($atts['limit']));
  $base  = rtrim((string) get_option(self::OPT_BASE_URL, 'https://dummyjson.com'), '/');

  // Si se usa "category", construimos el endpoint correcto
  if (!empty($atts['category'])) {
    // Permite letras, espacios, guiones y guiones bajos (se URL-encodea para seguridad)
    $cat = trim(preg_replace('/[^a-zA-Z0-9 _\-]/', '', (string)$atts['category']));
    $cat = strtolower(preg_replace('/\s+/', '%20', $cat)); // espacios a %20
    $endpoint = 'products/category/' . $cat;
  } else {
    // Permitir solo caracteres seguros en endpoint (incluye / ? = & - _)
    $endpoint = ltrim((string)$atts['endpoint'], '/');
    if (!preg_match('#^[a-zA-Z0-9/_\-\?\=\&]+$#', $endpoint)) {
      return '<div class="tocup-error">Endpoint inválido.</div>';
    }
  }

  // Construcción correcta de URL con limit
  $url = trailingslashit($base) . $endpoint;
  $url .= (strpos($endpoint, '?') === false) ? ('?limit=' . $limit) : ('&limit=' . $limit);

  // Caché (transients)
  $cache_key = 'tocup_products_' . md5($base . '|' . $endpoint . '|' . $limit);
  if ($atts['nocache'] === '1') {
    delete_transient($cache_key); // purga caché si lo pide
  } else {
    $cached = get_transient($cache_key);
    if ($cached !== false) { 
      return ($atts['debug'] === '1' ? '<small>URL: '.esc_html($url).'</small>'.$cached : $cached);
    }
  }

  // Llamada segura
  $args = ['timeout'=>10, 'headers'=>[]];
  $api_key = trim((string) get_option(self::OPT_API_KEY, ''));
  if ($api_key !== '') { $args['headers']['Authorization'] = 'Bearer ' . $api_key; }

  $resp = wp_safe_remote_get($url, $args);
  if (is_wp_error($resp)) {
    return '<div class="tocup-error">No se pudo conectar a la API.</div>';
  }
  $code = (int) wp_remote_retrieve_response_code($resp);
  if ($code !== 200) {
    return '<div class="tocup-error">API respondió con código '.esc_html($code).'.</div>';
  }

  $data  = json_decode(wp_remote_retrieve_body($resp), true);
  $items = $this->normalize_items($data);
  if (!$items) {
    return '<div class="tocup-error">No se encontraron productos.</div>';
  }

  ob_start(); ?>
  <?php if ($atts['debug'] === '1') : ?>
    <small>URL: <?php echo esc_html($url); ?></small>
  <?php endif; ?>
  <div class="tocup-grid">
    <?php foreach ($items as $p): ?>
      <article class="tocup-card">
        <div class="tocup-thumb">
          <?php if (!empty($p['thumbnail'])): ?>
            <img src="<?php echo esc_url($p['thumbnail']); ?>" alt="<?php echo esc_attr($p['title']); ?>" />
          <?php endif; ?>
        </div>
        <h3 class="tocup-title"><?php echo esc_html($p['title']); ?></h3>
        <p class="tocup-desc"><?php echo esc_html($p['description']); ?></p>
        <?php if ($p['price'] !== null): ?>
          <div class="tocup-price">$<?php echo esc_html(number_format((float)$p['price'], 2)); ?></div>
        <?php endif; ?>
      </article>
    <?php endforeach; ?>
  </div>
  <?php
  $html = ob_get_clean();
  set_transient($cache_key, $html, 10 * MINUTE_IN_SECONDS);
  return $html;
}

  // Normaliza estructuras comunes (DummyJSON / FakeStore / custom)
  private function normalize_items($data) {
    $raw = [];
    if (isset($data['products']) && is_array($data['products'])) { $raw = $data['products']; }
    elseif (is_array($data)) { $raw = $data; }

    $out = [];
    foreach ($raw as $p) {
      $out[] = [
        'title'       => $p['title'] ?? $p['name'] ?? $p['nombre'] ?? 'Producto',
        'price'       => $p['price'] ?? $p['precio'] ?? null,
        'thumbnail'   => $p['thumbnail'] ?? $p['image'] ?? $p['imagen'] ?? '',
        'description' => wp_trim_words($p['description'] ?? $p['descripcion'] ?? '', 18),
      ];
    }
    return $out;
  }

  /* ---------- Shortcode: Contacto (POST seguro) ---------- */
public function shortcode_contact() {
  $message = '';
  if (isset($_POST['tocup_submit'])) {
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'],'tocup_contact_nonce')) {
      $message = '<div class="tocup-error">Solicitud no válida (CSRF).</div>';
    } else {
      $name  = isset($_POST['name'])  ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
      $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
      $msg   = isset($_POST['message']) ? sanitize_textarea_field(wp_unslash($_POST['message'])) : '';
      if (empty($name) || empty($email) || !is_email($email)) {
        $message = '<div class="tocup-error">Datos inválidos. Verifica nombre y correo.</div>';
      } else {
        $resp = wp_safe_remote_post('https://httpbin.org/post', [
          'timeout'=>10,
          'body'   => ['name'=>$name,'email'=>$email,'message'=>$msg,'site'=>home_url()],
        ]);
        $message = (!is_wp_error($resp) && (int)wp_remote_retrieve_response_code($resp) < 300)
          ? '<div class="tocup-ok">✅ Mensaje enviado correctamente (simulado).</div>'
          : '<div class="tocup-error">No se pudo conectar al servicio externo.</div>';
      }
    }
  }

  $action = esc_url( get_permalink() ); // ← aquí garantizamos la URL correcta

  ob_start(); ?>
  <?php echo $message; ?>
  <form method="post" action="<?php echo $action; ?>" class="tocup-form" novalidate>
    <?php wp_nonce_field('tocup_contact_nonce'); ?>
    <p><label>Nombre<br><input type="text" name="name" required maxlength="80"></label></p>
    <p><label>Email<br><input type="email" name="email" required></label></p>
    <p><label>Mensaje<br><textarea name="message" rows="4" maxlength="500"></textarea></label></p>
    <p><button type="submit" name="tocup_submit">Enviar</button></p>
  </form>
  <?php
  return ob_get_clean();
}

  /* ---------- Estilos mínimos ---------- */
  public function enqueue_styles() {
    $css = "
    .tocup-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px}
    .tocup-card{border:1px solid #e5e7eb;border-radius:12px;padding:12px;background:#fff}
    .tocup-thumb{aspect-ratio:4/3;overflow:hidden;border-radius:10px;background:#f8fafc;display:flex;align-items:center;justify-content:center}
    .tocup-thumb img{max-width:100%;height:auto;display:block}
    .tocup-title{margin:10px 0 6px;font-size:1.05rem}
    .tocup-desc{color:#444;font-size:.9rem;min-height:38px}
    .tocup-price{margin-top:8px;font-weight:600}
    .tocup-ok{padding:8px 10px;background:#ecfdf5;border:1px solid #10b98126;border-radius:8px}
    .tocup-error{padding:8px 10px;background:#fef2f2;border:1px solid #ef444426;border-radius:8px}
    ";
    wp_register_style('tocup-api-css', false);
    wp_enqueue_style('tocup-api-css');
    wp_add_inline_style('tocup-api-css', $css);
  }
}

new ToCupboard_API_Integrations();
