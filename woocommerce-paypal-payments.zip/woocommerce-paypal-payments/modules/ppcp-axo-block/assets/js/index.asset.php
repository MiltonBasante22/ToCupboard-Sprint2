<?php

namespace {
    return array('dependencies' => array('wc-blocks-registry', 'wp-data', 'wp-element', 'wp-i18n'), 'version' => '5f76dc1043e385bcb565');
}
