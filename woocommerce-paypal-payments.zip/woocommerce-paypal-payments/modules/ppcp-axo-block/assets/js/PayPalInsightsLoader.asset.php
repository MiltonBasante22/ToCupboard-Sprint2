<?php

namespace {
    return array('dependencies' => array('wp-data', 'wp-element', 'wp-plugins'), 'version' => '7e84b16bc016f1b2d348');
}
