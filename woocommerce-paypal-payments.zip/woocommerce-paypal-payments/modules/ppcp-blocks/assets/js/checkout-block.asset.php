<?php

namespace {
    return array('dependencies' => array('react', 'wc-blocks-registry', 'wp-element', 'wp-i18n'), 'version' => '4667318b49891911046b');
}
