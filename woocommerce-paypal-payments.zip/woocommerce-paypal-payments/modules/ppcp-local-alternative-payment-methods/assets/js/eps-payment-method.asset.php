<?php

namespace {
    return array('dependencies' => array('wc-blocks-registry'), 'version' => 'edde9675b6ea24f1e3a0');
}
