<?php

namespace {
    return array('dependencies' => array(), 'version' => 'b372b5aafa35b6b8506e');
}
