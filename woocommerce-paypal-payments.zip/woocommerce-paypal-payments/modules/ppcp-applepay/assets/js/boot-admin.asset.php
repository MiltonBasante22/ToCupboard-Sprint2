<?php

namespace {
    return array('dependencies' => array(), 'version' => '13483d88c3e07d95758a');
}
