<?php

namespace {
    return array('dependencies' => array(), 'version' => 'e95a7cf79c9fe6bcced2');
}
