<?php

namespace {
    return array('dependencies' => array(), 'version' => '6731c4d25bbd18745444');
}
