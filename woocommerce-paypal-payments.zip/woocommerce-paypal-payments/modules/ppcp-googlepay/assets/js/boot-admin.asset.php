<?php

namespace {
    return array('dependencies' => array(), 'version' => '05a0ecbab0c8938c407c');
}
