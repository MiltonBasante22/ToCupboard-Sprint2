<?php

namespace {
    return array('dependencies' => array(), 'version' => '3f0612e4945061433330');
}
